function aplicarTema() {
    if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
        document.documentElement.setAttribute("data-bs-theme", "dark");
    } else {
        document.documentElement.setAttribute("data-bs-theme", "light");
    }
}

aplicarTema();
window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", aplicarTema);

function formatarPreco(valor) {
    return "R$ " + Number(valor).toLocaleString("pt-BR", { minimumFractionDigits: 2 });
}

function debounce(funcao, atraso) {
    let temporizador = null;
    return function (...argumentos) {
        clearTimeout(temporizador);
        temporizador = setTimeout(function () {
            funcao.apply(null, argumentos);
        }, atraso);
    };
}

function pegarCarrinho() {
    const dados = localStorage.getItem("carrinho");
    if (dados === null) {
        return [];
    }
    return JSON.parse(dados);
}

function salvarCarrinho(carrinho) {
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
}

function adicionarAoCarrinho(produto) {
    const carrinho = pegarCarrinho();
    let achou = false;

    for (let i = 0; i < carrinho.length; i++) {
        if (String(carrinho[i].id) === String(produto.id)) {
            carrinho[i].quantidade = carrinho[i].quantidade + 1;
            achou = true;
        }
    }

    if (achou === false) {
        carrinho.push(Object.assign({}, produto, { quantidade: 1 }));
    }

    salvarCarrinho(carrinho);
    atualizarCarrinhoHeader();
}

function contarItens() {
    const carrinho = pegarCarrinho();
    let total = 0;
    for (let i = 0; i < carrinho.length; i++) {
        total = total + carrinho[i].quantidade;
    }
    return total;
}

function atualizarCarrinhoHeader() {
    const badge = document.getElementById("badge-carrinho");
    const icone = document.getElementById("icone-carrinho");
    if (badge === null || icone === null) {
        return;
    }

    const total = contarItens();
    badge.textContent = total;

    if (total > 0) {
        icone.className = "bi bi-cart-fill";
    } else {
        icone.className = "bi bi-cart";
    }
}

function pegarUsuarioLogado() {
    const dados = localStorage.getItem("usuarioLogado");
    if (dados === null) {
        return null;
    }
    return JSON.parse(dados);
}

function exigirLogin() {
    const usuario = pegarUsuarioLogado();
    if (usuario === null) {
        window.location.href = "login.html";
        return null;
    }
    return usuario;
}

function sair() {
    localStorage.removeItem("usuarioLogado");
    window.location.href = "index.html";
}

function montarMenuUsuario() {
    const usuario = pegarUsuarioLogado();
    const menu = document.getElementById("menu-usuario");
    if (menu === null) {
        return;
    }

    if (usuario === null) {
        document.getElementById("saudacao").textContent = "Olá, visitante";
        menu.innerHTML = '<li><a class="dropdown-item" href="novo_usuario.html">Cadastrar</a></li>';
        menu.innerHTML += '<li><a class="dropdown-item" href="login.html">Entrar</a></li>';
    } else {
        const primeiroNome = (usuario.nome || "").split(" ")[0] || usuario.email;
        document.getElementById("saudacao").textContent = "Olá, " + primeiroNome;
        menu.innerHTML = '<li><a class="dropdown-item" href="dados_pessoais.html">Meus Dados</a></li>';
        menu.innerHTML += '<li><a class="dropdown-item" href="meus_pedidos.html">Meus Pedidos</a></li>';
        menu.innerHTML += '<li><a class="dropdown-item" href="#" id="botao-sair">Sair</a></li>';

        document.getElementById("botao-sair").addEventListener("click", function (evento) {
            evento.preventDefault();
            sair();
        });
    }
}

function pegarPedidos() {
    const dados = localStorage.getItem("pedidos");
    if (dados === null) {
        return [];
    }
    return JSON.parse(dados);
}

function salvarPedidos(pedidos) {
    localStorage.setItem("pedidos", JSON.stringify(pedidos));
}

function pegarEnderecos() {
    const dados = localStorage.getItem("enderecos");
    if (dados === null) {
        return [];
    }
    return JSON.parse(dados);
}

function salvarEnderecos(enderecos) {
    localStorage.setItem("enderecos", JSON.stringify(enderecos));
}

function pegarFavoritos() {
    const dados = localStorage.getItem("favoritos");
    if (dados === null) {
        return [];
    }
    return JSON.parse(dados);
}

function salvarFavoritos(favoritos) {
    localStorage.setItem("favoritos", JSON.stringify(favoritos));
}

function alternarFavorito(idProduto) {
    let favoritos = pegarFavoritos();
    const indice = favoritos.indexOf(String(idProduto));

    if (indice === -1) {
        favoritos.push(String(idProduto));
    } else {
        favoritos.splice(indice, 1);
    }

    salvarFavoritos(favoritos);
    return favoritos.indexOf(String(idProduto)) !== -1;
}

function produtoEhFavorito(idProduto) {
    return pegarFavoritos().indexOf(String(idProduto)) !== -1;
}

function exibirAlerta(container, tipo, mensagem) {
    container.innerHTML = '<div class="alert alert-' + tipo + ' mb-3" role="alert">' + mensagem + "</div>";
}

montarMenuUsuario();
atualizarCarrinhoHeader();
