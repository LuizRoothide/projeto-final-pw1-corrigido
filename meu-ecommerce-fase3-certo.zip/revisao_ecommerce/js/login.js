const formulario = document.getElementById("form-login");
const areaMensagem = document.getElementById("area-mensagem");
const botaoLogin = formulario.querySelector("button[type='submit']");

formulario.addEventListener("submit", async function (evento) {
    evento.preventDefault();
    areaMensagem.innerHTML = "";

    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value;

    if (email === "" || senha === "") {
        exibirAlerta(areaMensagem, "warning", "Informe e-mail e senha.");
        return;
    }

    botaoLogin.disabled = true;
    const resposta = await logarUsuario(email, senha);
    botaoLogin.disabled = false;

    if (resposta.erroRede) {
        exibirAlerta(areaMensagem, "danger", "Não foi possível conectar à loja agora. Tente novamente em instantes.");
        return;
    }

    if (resposta.status === 200 && resposta.ok) {
        const usuario = extrairObjeto(resposta.data, ["usuario", "user", "dados", "data"]) || { nome: email, email: email };
        if (!usuario.email) {
            usuario.email = email;
        }
        localStorage.setItem("usuarioLogado", JSON.stringify(usuario));
        window.location.href = "index.html";
        return;
    }

    if (resposta.status === 400) {
        exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "Informe e-mail e senha."));
        return;
    }

    if (resposta.status === 401) {
        exibirAlerta(areaMensagem, "danger", extrairMensagem(resposta.data, "E-mail ou senha incorretos."));
        return;
    }

    exibirAlerta(areaMensagem, "danger", extrairMensagem(resposta.data, "Não foi possível entrar agora."));
});
