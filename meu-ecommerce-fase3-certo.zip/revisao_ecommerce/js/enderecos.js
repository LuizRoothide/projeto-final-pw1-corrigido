const usuarioAtual = exigirLogin();

if (usuarioAtual !== null) {
    const listaEnderecos = document.getElementById("lista-enderecos");
    const formulario = document.getElementById("form-endereco");
    const areaMensagemModal = document.getElementById("area-mensagem-modal");
    const campoCep = document.getElementById("campo-cep-endereco");
    const campoRua = document.getElementById("campo-rua");
    const campoNumero = document.getElementById("campo-numero");
    const campoCidadeEstado = document.getElementById("campo-cidade-estado");
    const indicadorCep = document.getElementById("indicador-cep");
    const modalEndereco = new bootstrap.Modal(document.getElementById("modal-endereco"));

    function montarCardEndereco(endereco) {
        const div = document.createElement("div");
        div.className = "card mb-3";
        div.innerHTML =
            '<div class="card-body d-flex justify-content-between align-items-center">' +
            "<div>" +
            '<input type="hidden" class="endereco-id" value="' + endereco.id + '">' +
            "<h5>" + endereco.rua + ", " + endereco.numero + "</h5>" +
            '<p class="mb-0">' + endereco.cidadeEstado + " - CEP " + endereco.cep + "</p>" +
            "</div>" +
            '<button type="button" class="btn btn-outline-danger botao-excluir" data-id="' + endereco.id + '">' +
            '<i class="bi bi-trash"></i> Excluir Endereço' +
            "</button>" +
            "</div>";
        return div;
    }

    function renderizarEnderecos() {
        const enderecos = pegarEnderecos();
        listaEnderecos.innerHTML = "";

        if (enderecos.length === 0) {
            listaEnderecos.innerHTML = '<div class="alert alert-info">Você ainda não cadastrou nenhum endereço.</div>';
            return;
        }

        for (let i = 0; i < enderecos.length; i++) {
            listaEnderecos.appendChild(montarCardEndereco(enderecos[i]));
        }

        const botoesExcluir = document.querySelectorAll(".botao-excluir");
        for (let i = 0; i < botoesExcluir.length; i++) {
            botoesExcluir[i].addEventListener("click", function () {
                excluirEndereco(botoesExcluir[i].getAttribute("data-id"));
            });
        }
    }

    function excluirEndereco(id) {
        const enderecos = pegarEnderecos().filter(function (endereco) {
            return String(endereco.id) !== String(id);
        });
        salvarEnderecos(enderecos);
        renderizarEnderecos();
    }

    async function buscarCepAutomatico() {
        const cepDigitado = campoCep.value.replace(/\D/g, "");
        if (cepDigitado.length !== 8) {
            return;
        }

        indicadorCep.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';

        try {
            const resposta = await fetch("https://viacep.com.br/ws/" + cepDigitado + "/json/");
            const dados = await resposta.json();

            if (dados.erro) {
                exibirAlerta(areaMensagemModal, "warning", "CEP não encontrado.");
            } else {
                campoRua.value = dados.logradouro || "";
                campoCidadeEstado.value = (dados.localidade || "") + "/" + (dados.uf || "");
                areaMensagemModal.innerHTML = "";
            }
        } catch (erro) {
            exibirAlerta(areaMensagemModal, "warning", "Não foi possível consultar o CEP automaticamente. Preencha manualmente.");
        }

        indicadorCep.innerHTML = '<i class="bi bi-search"></i>';
    }

    campoCep.addEventListener("blur", buscarCepAutomatico);

    formulario.addEventListener("submit", function (evento) {
        evento.preventDefault();
        areaMensagemModal.innerHTML = "";

        const cep = campoCep.value.trim();
        const rua = campoRua.value.trim();
        const numero = campoNumero.value.trim();
        const cidadeEstado = campoCidadeEstado.value.trim();

        if (cep === "" || rua === "" || numero === "" || cidadeEstado === "") {
            exibirAlerta(areaMensagemModal, "warning", "Preencha todos os campos.");
            return;
        }

        const enderecos = pegarEnderecos();
        enderecos.push({ id: Date.now(), cep: cep, rua: rua, numero: numero, cidadeEstado: cidadeEstado });
        salvarEnderecos(enderecos);

        formulario.reset();
        modalEndereco.hide();
        renderizarEnderecos();
    });

    renderizarEnderecos();
}
