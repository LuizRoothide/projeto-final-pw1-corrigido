const usuarioAtual = exigirLogin();

if (usuarioAtual !== null) {
    const listaPedidos = document.getElementById("lista-pedidos");
    const areaMensagem = document.getElementById("area-mensagem");

    function montarCardPedido(pedido) {
        const statusLower = String(pedido.status).toLowerCase();
        const podeCancelar = statusLower.indexOf("cancelado") === -1 && statusLower.indexOf("enviado") === -1 && statusLower.indexOf("entregue") === -1;

        const div = document.createElement("div");
        div.className = "card mb-3";
        div.innerHTML =
            '<div class="card-body">' +
            '<h5 class="card-title">Pedido ' + pedido.protocolo + "</h5>" +
            '<p class="mb-1">Status: <span class="badge bg-secondary">' + pedido.status + "</span></p>" +
            '<p class="mb-1">CEP de entrega: ' + pedido.cep + "</p>" +
            '<p class="mb-1">Forma de pagamento: ' + pedido.metodoPagamento + "</p>" +
            '<p class="mb-1">Itens: ' + pedido.totalItens + "</p>" +
            '<p class="mb-3">Valor dos produtos: ' + formatarPreco(pedido.valorProdutos) + "</p>" +
            '<a class="btn btn-outline-primary btn-sm me-2" href="pedido.html?id=' + encodeURIComponent(pedido.protocolo) + '">Visualizar Detalhes do Pedido</a>' +
            '<button type="button" class="btn btn-outline-danger btn-sm botao-cancelar" data-protocolo="' + pedido.protocolo + '"' + (podeCancelar ? "" : " disabled") + ">Cancelar Pedido</button>" +
            "</div>";

        return div;
    }

    function renderizarPedidos() {
        const pedidos = pegarPedidos();
        listaPedidos.innerHTML = "";

        if (pedidos.length === 0) {
            listaPedidos.innerHTML = '<div class="alert alert-info">Você ainda não possui pedidos.</div>';
            return;
        }

        for (let i = pedidos.length - 1; i >= 0; i--) {
            listaPedidos.appendChild(montarCardPedido(pedidos[i]));
        }

        const botoesCancelar = document.querySelectorAll(".botao-cancelar");
        for (let i = 0; i < botoesCancelar.length; i++) {
            botoesCancelar[i].addEventListener("click", function () {
                cancelarPedido(botoesCancelar[i].getAttribute("data-protocolo"));
            });
        }
    }

    async function cancelarPedido(protocolo) {
        areaMensagem.innerHTML = "";

        const resposta = await cancelarPedidoApi(protocolo);

        if (resposta.erroRede) {
            exibirAlerta(areaMensagem, "danger", "Não foi possível conectar à loja agora.");
            return;
        }

        if (resposta.status === 400) {
            exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "Protocolo não informado."));
            return;
        }

        if (resposta.status === 404) {
            exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "Este protocolo não foi encontrado."));
            return;
        }

        if (resposta.status === 422) {
            exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "Este pedido já foi enviado e não pode mais ser cancelado."));
            return;
        }

        if (resposta.status !== 200 || !resposta.ok) {
            exibirAlerta(areaMensagem, "danger", extrairMensagem(resposta.data, "Não foi possível cancelar o pedido."));
            return;
        }

        const pedidos = pegarPedidos();
        for (let i = 0; i < pedidos.length; i++) {
            if (pedidos[i].protocolo === protocolo) {
                pedidos[i].status = "cancelado";
            }
        }
        salvarPedidos(pedidos);

        exibirAlerta(areaMensagem, "success", extrairMensagem(resposta.data, "Pedido cancelado com sucesso!"));
        renderizarPedidos();
    }

    renderizarPedidos();
}
