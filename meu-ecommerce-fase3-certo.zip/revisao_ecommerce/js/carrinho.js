const lista = document.getElementById("lista-carrinho");
const areaMensagem = document.getElementById("area-mensagem");
const areaMensagemFrete = document.getElementById("area-mensagem-frete");
const areaMensagemCupom = document.getElementById("area-mensagem-cupom");
const opcoesFrete = document.getElementById("opcoes-frete");
const areaEndereco = document.getElementById("area-endereco");
const areaCartao = document.getElementById("area-cartao");
const botaoFinalizar = document.getElementById("botao-finalizar");

let freteSelecionado = null;
let cupomAplicado = null;
let opcoesFreteCarregadas = [];

function extrairCampo(objeto, chaves, padrao) {
    for (let i = 0; i < chaves.length; i++) {
        if (objeto && objeto[chaves[i]] !== undefined && objeto[chaves[i]] !== null) {
            return objeto[chaves[i]];
        }
    }
    return padrao;
}

function calcularSubtotal() {
    const carrinho = pegarCarrinho();
    let subtotal = 0;
    for (let i = 0; i < carrinho.length; i++) {
        subtotal = subtotal + carrinho[i].preco * carrinho[i].quantidade;
    }
    return subtotal;
}

function renderizarItensCarrinho() {
    const carrinho = pegarCarrinho();
    lista.innerHTML = "";

    if (carrinho.length === 0) {
        lista.innerHTML = '<div class="alert alert-info">Seu carrinho está vazio.</div>';
        botaoFinalizar.disabled = true;
    } else {
        botaoFinalizar.disabled = false;
    }

    for (let i = 0; i < carrinho.length; i++) {
        const item = carrinho[i];
        const subtotalItem = item.preco * item.quantidade;

        lista.innerHTML +=
            '<div class="card mb-3">' +
            '<div class="card-body d-flex align-items-center">' +
            '<img src="' + item.imagem + '" class="img-carrinho me-3" alt="' + item.nome + '">' +
            '<div class="flex-grow-1">' +
            "<h5>" + item.nome + "</h5>" +
            '<p class="mb-1">' + (item.descricao || "") + "</p>" +
            '<p class="mb-1">Preço: ' + formatarPreco(item.preco) + "</p>" +
            '<span class="badge bg-primary" data-bs-toggle="tooltip" title="Quantidade deste produto">Quantidade: ' + item.quantidade + "</span>" +
            "</div>" +
            '<div class="text-end ms-3">' +
            '<p class="preco mb-2">' + formatarPreco(subtotalItem) + "</p>" +
            '<button type="button" class="btn btn-outline-danger btn-sm botao-remover-item" data-indice="' + i + '" aria-label="Remover ' + item.nome + ' do carrinho">' +
            '<i class="bi bi-trash"></i> Remover' +
            '</button>' +
            '</div>' +
            "</div>" +
            "</div>";
    }

    const dicas = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    for (let i = 0; i < dicas.length; i++) {
        new bootstrap.Tooltip(dicas[i]);
    }

    document.getElementById("quantidade-total").textContent = contarItens();
    document.getElementById("subtotal").textContent = formatarPreco(calcularSubtotal());
}

function calcularDesconto(subtotal, valorFrete) {
    if (cupomAplicado === null) {
        return { descontoProdutos: 0, freteGratis: false };
    }

    const tipo = String(extrairCampo(cupomAplicado, ["tipo", "tipoDesconto"], "")).toLowerCase();
    const valor = Number(extrairCampo(cupomAplicado, ["desconto", "valor", "percentual"], 0));

    if (tipo.indexOf("frete") !== -1) {
        return { descontoProdutos: 0, freteGratis: true };
    }

    if (tipo.indexOf("percentual") !== -1 || tipo.indexOf("porcent") !== -1) {
        const percentual = valor > 1 ? valor / 100 : valor;
        return { descontoProdutos: subtotal * percentual, freteGratis: false };
    }

    return { descontoProdutos: valor, freteGratis: false };
}

function atualizarResumo() {
    const subtotal = calcularSubtotal();
    const valorFrete = freteSelecionado ? Number(extrairCampo(freteSelecionado, ["valor", "preco", "price"], 0)) : 0;
    const resultadoDesconto = calcularDesconto(subtotal, valorFrete);
    const freteFinal = resultadoDesconto.freteGratis ? 0 : valorFrete;
    const total = Math.max(0, subtotal - resultadoDesconto.descontoProdutos) + freteFinal;

    document.getElementById("valor-frete").textContent = formatarPreco(freteFinal);
    document.getElementById("valor-desconto").textContent = formatarPreco(resultadoDesconto.descontoProdutos);
    document.getElementById("total").textContent = formatarPreco(total);

    return { subtotal: subtotal, frete: freteFinal, desconto: resultadoDesconto.descontoProdutos, total: total };
}

function renderizarOpcoesFrete(opcoes) {
    opcoesFreteCarregadas = opcoes;
    opcoesFrete.innerHTML = "";

    if (opcoes.length === 0) {
        return;
    }

    for (let i = 0; i < opcoes.length; i++) {
        const opcao = opcoes[i];
        const nome = extrairCampo(opcao, ["nome", "transportadora", "servico", "tipo"], "Opção " + (i + 1));
        const valor = Number(extrairCampo(opcao, ["valor", "preco", "price"], 0));
        const prazo = extrairCampo(opcao, ["prazo", "prazoDias", "dias", "prazoEntrega"], null);

        const div = document.createElement("div");
        div.className = "form-check";
        div.innerHTML =
            '<input class="form-check-input" type="radio" name="frete" id="frete-' + i + '" value="' + i + '">' +
            '<label class="form-check-label" for="frete-' + i + '">' + nome + " - " + formatarPreco(valor) +
            (prazo ? " (" + prazo + " dias úteis)" : "") +
            "</label>";
        opcoesFrete.appendChild(div);
    }

    const radios = opcoesFrete.querySelectorAll("input[name='frete']");
    for (let i = 0; i < radios.length; i++) {
        radios[i].addEventListener("change", function () {
            freteSelecionado = opcoesFreteCarregadas[Number(radios[i].value)];
            atualizarResumo();
        });
    }

    radios[0].checked = true;
    freteSelecionado = opcoesFreteCarregadas[0];
    atualizarResumo();
}

document.getElementById("botao-calcular-frete").addEventListener("click", async function () {
    areaMensagemFrete.innerHTML = "";
    opcoesFrete.innerHTML = "";
    freteSelecionado = null;

    const cep = document.getElementById("campo-cep").value.trim();

    if (cep === "") {
        exibirAlerta(areaMensagemFrete, "warning", "Informe o CEP.");
        return;
    }

    const resposta = await calcularFrete(cep);

    if (resposta.erroRede) {
        exibirAlerta(areaMensagemFrete, "danger", "Não foi possível conectar à loja agora.");
        return;
    }

    if (resposta.status === 400) {
        exibirAlerta(areaMensagemFrete, "warning", extrairMensagem(resposta.data, "CEP em formato inválido. Use o formato 99999-999."));
        return;
    }

    if (resposta.status === 404) {
        exibirAlerta(areaMensagemFrete, "warning", extrairMensagem(resposta.data, "CEP não encontrado."));
        return;
    }

    if (resposta.status === 422) {
        exibirAlerta(areaMensagemFrete, "warning", extrairMensagem(resposta.data, "Essa região ainda não é atendida."));
        return;
    }

    if (!resposta.ok) {
        exibirAlerta(areaMensagemFrete, "danger", extrairMensagem(resposta.data, "Não foi possível calcular o frete."));
        return;
    }

    const opcoes = extrairLista(resposta.data, ["fretes", "opcoes", "data"]);
    if (opcoes.length === 0) {
        exibirAlerta(areaMensagemFrete, "warning", "Nenhuma opção de frete disponível para este CEP.");
        return;
    }

    renderizarOpcoesFrete(opcoes);
});

document.getElementById("botao-aplicar-cupom").addEventListener("click", async function () {
    areaMensagemCupom.innerHTML = "";

    const codigo = document.getElementById("campo-cupom").value.trim();
    if (codigo === "") {
        exibirAlerta(areaMensagemCupom, "warning", "Informe o código do cupom.");
        return;
    }

    const subtotal = calcularSubtotal();
    const resposta = await aplicarCupom(codigo, subtotal);

    if (resposta.erroRede) {
        exibirAlerta(areaMensagemCupom, "danger", "Não foi possível conectar à loja agora.");
        return;
    }

    if (resposta.status === 400) {
        exibirAlerta(areaMensagemCupom, "warning", extrairMensagem(resposta.data, "Informe um código de cupom válido."));
        cupomAplicado = null;
        atualizarResumo();
        return;
    }

    if (resposta.status === 404) {
        exibirAlerta(areaMensagemCupom, "warning", extrairMensagem(resposta.data, "Cupom inexistente."));
        cupomAplicado = null;
        atualizarResumo();
        return;
    }

    if (resposta.status === 410) {
        exibirAlerta(areaMensagemCupom, "warning", extrairMensagem(resposta.data, "Este cupom está expirado."));
        cupomAplicado = null;
        atualizarResumo();
        return;
    }

    if (resposta.status === 422) {
        exibirAlerta(areaMensagemCupom, "warning", extrairMensagem(resposta.data, "Esse cupom não pode ser aplicado a este pedido."));
        cupomAplicado = null;
        atualizarResumo();
        return;
    }

    if (!resposta.ok) {
        exibirAlerta(areaMensagemCupom, "danger", extrairMensagem(resposta.data, "Não foi possível aplicar o cupom."));
        cupomAplicado = null;
        atualizarResumo();
        return;
    }

    cupomAplicado = resposta.data && resposta.data.cupom
        ? resposta.data.cupom
        : Object.assign({ codigo: codigo }, resposta.data || {});
    exibirAlerta(areaMensagemCupom, "success", extrairMensagem(resposta.data, "Cupom aplicado com sucesso!"));
    atualizarResumo();
});

function renderizarSelecaoEndereco() {
    const enderecos = pegarEnderecos();

    if (enderecos.length === 0) {
        areaEndereco.innerHTML = '<p class="mb-0">Você ainda não cadastrou um endereço. <a href="enderecos.html">Cadastrar endereço</a></p>';
        return;
    }

    let html = '<label for="campo-endereco" class="form-label">Endereço de entrega</label>';
    html += '<select class="form-select" id="campo-endereco">';
    for (let i = 0; i < enderecos.length; i++) {
        const endereco = enderecos[i];
        html += '<option value="' + endereco.id + '" data-cep="' + endereco.cep + '">' + endereco.rua + ", " + endereco.numero + " - " + endereco.cidadeEstado + " (CEP " + endereco.cep + ")</option>";
    }
    html += "</select>";
    areaEndereco.innerHTML = html;
    const seletor = document.getElementById("campo-endereco");
    seletor.addEventListener("change", sincronizarCepDoEndereco);
    sincronizarCepDoEndereco();
}

function sincronizarCepDoEndereco() {
    const seletor = document.getElementById("campo-endereco");
    if (!seletor || seletor.selectedIndex < 0) return;
    const opcao = seletor.options[seletor.selectedIndex];
    const campoCep = document.getElementById("campo-cep");
    campoCep.value = opcao.getAttribute("data-cep") || "";
    // O frete calculado para o CEP anterior não pode continuar selecionado.
    freteSelecionado = null;
    opcoesFrete.innerHTML = "";
    atualizarResumo();
}

const radiosPagamento = document.querySelectorAll("input[name='pagamento']");
for (let i = 0; i < radiosPagamento.length; i++) {
    radiosPagamento[i].addEventListener("change", function () {
        if (radiosPagamento[i].value === "cartao" && radiosPagamento[i].checked) {
            areaCartao.classList.remove("d-none");
        } else if (radiosPagamento[i].checked) {
            areaCartao.classList.add("d-none");
        }
    });
}

function pegarMetodoPagamentoSelecionado() {
    for (let i = 0; i < radiosPagamento.length; i++) {
        if (radiosPagamento[i].checked) {
            return radiosPagamento[i].value;
        }
    }
    return "pix";
}

botaoFinalizar.addEventListener("click", async function () {
    areaMensagem.innerHTML = "";

    const carrinho = pegarCarrinho();
    if (carrinho.length === 0) {
        exibirAlerta(areaMensagem, "warning", "Seu carrinho está vazio.");
        return;
    }

    const cep = document.getElementById("campo-cep").value.trim();
    if (cep === "") {
        exibirAlerta(areaMensagem, "warning", "Informe e calcule o CEP de entrega antes de finalizar.");
        return;
    }

    const metodoPagamento = pegarMetodoPagamentoSelecionado();
    const numeroCartao = document.getElementById("campo-numero-cartao").value.trim();

    const itens = carrinho.map(function (item) {
        return { id: item.id, quantidade: item.quantidade };
    });

    botaoFinalizar.disabled = true;
    const resposta = await finalizarCompra(itens, cep, metodoPagamento, metodoPagamento === "cartao" ? numeroCartao : undefined);
    botaoFinalizar.disabled = false;

    if (resposta.erroRede) {
        exibirAlerta(areaMensagem, "danger", "Não foi possível conectar à loja agora.");
        return;
    }

    if (resposta.status === 400) {
        exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "Verifique o carrinho, o CEP, a forma de pagamento e o número do cartão."));
        return;
    }

    if (resposta.status === 402) {
        exibirAlerta(areaMensagem, "danger", extrairMensagem(resposta.data, "Cartão recusado. Tente outro cartão ou outra forma de pagamento."));
        return;
    }

    if (resposta.status === 404) {
        exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "Algum produto do carrinho não existe mais."));
        return;
    }

    if (resposta.status === 422) {
        exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "Estoque insuficiente para algum item do carrinho."));
        return;
    }

    if (resposta.status !== 201) {
        exibirAlerta(areaMensagem, "danger", extrairMensagem(resposta.data, "A API não confirmou a criação do pedido (esperado HTTP 201)."));
        return;
    }

    const pedidoRetornado = extrairObjeto(resposta.data, ["pedido", "data", "resultado"]) || resposta.data;
    const enderecoSelecionado = document.getElementById("campo-endereco");

    const resumoFinanceiro = atualizarResumo();
    const pedidoSalvo = {
        protocolo: extrairCampo(pedidoRetornado, ["protocolo"], "PED-DESCONHECIDO"),
        status: extrairCampo(pedidoRetornado, ["status"], "em processamento"),
        cep: extrairCampo(pedidoRetornado, ["cep"], cep),
        metodoPagamento: extrairCampo(pedidoRetornado, ["metodoPagamento"], metodoPagamento),
        totalItens: extrairCampo(pedidoRetornado, ["totalItens"], contarItens()),
        valorProdutos: extrairCampo(pedidoRetornado, ["valorProdutos"], calcularSubtotal()),
        freteCalculado: resumoFinanceiro.frete,
        descontoAplicado: resumoFinanceiro.desconto,
        totalExibido: resumoFinanceiro.total,
        cupom: cupomAplicado ? cupomAplicado.codigo : null,
        endereco: enderecoSelecionado
            ? pegarEnderecos().find((e) => String(e.id) === enderecoSelecionado.value && String(e.cep).trim() === cep) || null
            : null,
        itens: carrinho
    };

    const pedidos = pegarPedidos();
    pedidos.push(pedidoSalvo);
    salvarPedidos(pedidos);

    localStorage.removeItem("carrinho");
    window.location.href = "sucesso-pedido.html?protocolo=" + encodeURIComponent(pedidoSalvo.protocolo);
});

// Remove o produto selecionado e atualiza carrinho, resumo e contador do cabeçalho.
lista.addEventListener("click", function (evento) {
    const botao = evento.target.closest(".botao-remover-item");
    if (!botao) return;

    const indice = Number(botao.dataset.indice);
    const carrinhoAtual = pegarCarrinho();
    if (!Number.isInteger(indice) || indice < 0 || indice >= carrinhoAtual.length) return;

    carrinhoAtual.splice(indice, 1);
    salvarCarrinho(carrinhoAtual);
    atualizarCarrinhoHeader();
    renderizarItensCarrinho();
    atualizarResumo();
    exibirAlerta(areaMensagem, "success", "Produto removido do carrinho.");
});

renderizarItensCarrinho();
renderizarSelecaoEndereco();
atualizarResumo();
