const usuarioAtual = exigirLogin();

if (usuarioAtual !== null) {
    const conteudoPedido = document.getElementById("conteudo-pedido");
    const protocolo = new URLSearchParams(window.location.search).get("id");
    const pedidos = pegarPedidos();
    const pedido = pedidos.find(function (item) {
        return item.protocolo === protocolo;
    });

    if (!pedido) {
        conteudoPedido.innerHTML = '<div class="alert alert-warning">Pedido não encontrado.</div>';
    } else {
        let itensHtml = "";
        const itens = pedido.itens || [];
        for (let i = 0; i < itens.length; i++) {
            const item = itens[i];
            itensHtml +=
                '<li class="list-group-item d-flex justify-content-between align-items-center">' +
                item.nome + " (x" + item.quantidade + ")" +
                '<span>' + formatarPreco(item.preco * item.quantidade) + "</span>" +
                "</li>";
        }

        const enderecoHtml = pedido.endereco
            ? pedido.endereco.rua + ", " + pedido.endereco.numero + " - " + pedido.endereco.cidadeEstado + " (CEP " + pedido.endereco.cep + ")"
            : "Não informado";

        conteudoPedido.innerHTML =
            '<div class="card mb-3">' +
            '<div class="card-body">' +
            "<h4>Protocolo: " + pedido.protocolo + "</h4>" +
            '<p class="mb-1">Status: <span class="badge bg-secondary">' + pedido.status + "</span></p>" +
            '<p class="mb-1">CEP de entrega: ' + pedido.cep + "</p>" +
            '<p class="mb-1">Endereço de entrega: ' + enderecoHtml + "</p>" +
            '<p class="mb-1">Forma de pagamento: ' + pedido.metodoPagamento + "</p>" +
            '<p class="mb-1">Total de itens: ' + pedido.totalItens + "</p>" +
            '<p class="mb-1">Valor dos produtos: ' + formatarPreco(pedido.valorProdutos) + "</p>" +
            (pedido.freteCalculado !== undefined ? '<p class="mb-1">Frete calculado: ' + formatarPreco(pedido.freteCalculado) + "</p>" : "") +
            (pedido.descontoAplicado !== undefined ? '<p class="mb-1">Desconto aplicado: ' + formatarPreco(pedido.descontoAplicado) + "</p>" : "") +
            (pedido.totalExibido !== undefined ? '<p class="mb-3 fw-bold">Total exibido no carrinho: ' + formatarPreco(pedido.totalExibido) + "</p>" : "") +
            "<h5>Itens do pedido</h5>" +
            '<ul class="list-group">' + itensHtml + "</ul>" +
            "</div>" +
            "</div>";
    }
}
