let produtosCarregados = [];

const listaProdutos = document.getElementById("lista-produtos");
const campoBusca = document.getElementById("campo-busca");
const campoCategoria = document.getElementById("campo-categoria");
const areaMensagem = document.getElementById("area-mensagem");
const carregando = document.getElementById("carregando");

function montarCardProduto(produto) {
    const esgotado = Number(produto.stock) === 0;
    const favorito = produtoEhFavorito(produto.id);

    const coluna = document.createElement("div");
    coluna.className = "col";
    coluna.innerHTML =
        '<div class="card h-100 text-center' + (esgotado ? " card-esgotado" : "") + '">' +
        '<button type="button" class="btn-favorito botao-favorito" data-id="' + produto.id + '">' +
        '<i class="bi ' + (favorito ? "bi-heart-fill" : "bi-heart") + '"></i>' +
        "</button>" +
        '<img src="' + produto.image + '" class="card-img-top produto-imagem-arrastavel" alt="' + produto.name + '" draggable="true" data-id="' + produto.id + '">' +
        '<div class="card-body d-flex flex-column">' +
        '<h5 class="card-title">' + produto.name + "</h5>" +
        '<p class="card-text">' + produto.description + "</p>" +
        '<span class="badge bg-secondary mb-2 align-self-center">' + produto.category + "</span>" +
        '<p class="preco">' + formatarPreco(produto.price) + "</p>" +
        (esgotado ? '<p class="badge-esgotado">Esgotado</p>' : "") +
        '<input type="hidden" class="produto-id" value="' + produto.id + '">' +
        '<button type="button" class="btn btn-primary botao-adicionar mt-auto" data-id="' + produto.id + '"' + (esgotado ? " disabled" : "") + ">" +
        (esgotado ? "Indisponível" : "Adicionar ao carrinho") +
        "</button>" +
        "</div>" +
        "</div>";

    return coluna;
}

function renderizarProdutos(produtos) {
    listaProdutos.innerHTML = "";

    if (produtos.length === 0) {
        areaMensagem.innerHTML = '<div class="alert alert-info">Nenhum produto encontrado.</div>';
        return;
    }

    areaMensagem.innerHTML = "";
    for (let i = 0; i < produtos.length; i++) {
        listaProdutos.appendChild(montarCardProduto(produtos[i]));
    }

    registrarEventosDosCards();
}

function mostrarToast(mensagem) {
    document.getElementById("toast-mensagem").textContent = mensagem;
    const toast = new bootstrap.Toast(document.getElementById("toast-carrinho"));
    toast.show();
}

function adicionarProdutoAoCarrinho(idProduto) {
    const produto = produtosCarregados.find(function (item) {
        return String(item.id) === String(idProduto);
    });

    if (!produto || Number(produto.stock) === 0) {
        return;
    }

    adicionarAoCarrinho({
        id: produto.id,
        nome: produto.name,
        descricao: produto.description,
        preco: Number(produto.price),
        imagem: produto.image
    });

    mostrarToast(produto.name + " foi adicionado ao carrinho!");
}

function registrarEventosDosCards() {
    const botoesAdicionar = document.querySelectorAll(".botao-adicionar");
    for (let i = 0; i < botoesAdicionar.length; i++) {
        botoesAdicionar[i].addEventListener("click", function () {
            adicionarProdutoAoCarrinho(botoesAdicionar[i].getAttribute("data-id"));
        });
    }

    const botoesFavorito = document.querySelectorAll(".botao-favorito");
    for (let i = 0; i < botoesFavorito.length; i++) {
        botoesFavorito[i].addEventListener("click", function () {
            const id = botoesFavorito[i].getAttribute("data-id");
            const agoraEhFavorito = alternarFavorito(id);
            const icone = botoesFavorito[i].querySelector("i");
            icone.className = agoraEhFavorito ? "bi bi-heart-fill" : "bi bi-heart";
        });
    }

    const imagensArrastaveis = document.querySelectorAll(".produto-imagem-arrastavel");
    for (let i = 0; i < imagensArrastaveis.length; i++) {
        imagensArrastaveis[i].addEventListener("dragstart", function (evento) {
            evento.dataTransfer.setData("text/plain", imagensArrastaveis[i].getAttribute("data-id"));
        });
    }
}

function configurarAreaDeDrop() {
    const areaCarrinho = document.getElementById("area-carrinho");

    areaCarrinho.addEventListener("dragover", function (evento) {
        evento.preventDefault();
        areaCarrinho.classList.add("area-drop-ativa");
    });

    areaCarrinho.addEventListener("dragleave", function () {
        areaCarrinho.classList.remove("area-drop-ativa");
    });

    areaCarrinho.addEventListener("drop", function (evento) {
        evento.preventDefault();
        areaCarrinho.classList.remove("area-drop-ativa");
        const idProduto = evento.dataTransfer.getData("text/plain");
        if (idProduto) {
            adicionarProdutoAoCarrinho(idProduto);
        }
    });
}

async function carregarProdutos() {
    carregando.classList.remove("d-none");
    areaMensagem.innerHTML = "";

    const filtros = {
        busca: campoBusca.value.trim(),
        categoria: campoCategoria.value
    };

    const resposta = await buscarProdutos(filtros);
    carregando.classList.add("d-none");

    if (resposta.erroRede) {
        exibirAlerta(areaMensagem, "danger", "Não foi possível conectar à loja agora. Tente novamente em instantes.");
        listaProdutos.innerHTML = "";
        return;
    }

    if (!resposta.ok) {
        exibirAlerta(areaMensagem, "danger", extrairMensagem(resposta.data, "Não foi possível carregar os produtos."));
        listaProdutos.innerHTML = "";
        return;
    }

    produtosCarregados = extrairLista(resposta.data, ["produtos", "products", "data", "items", "resultado"]);
    renderizarProdutos(produtosCarregados);
}

const buscarComDebounce = debounce(carregarProdutos, 500);

campoBusca.addEventListener("input", buscarComDebounce);
campoCategoria.addEventListener("change", carregarProdutos);

configurarAreaDeDrop();
carregarProdutos();
