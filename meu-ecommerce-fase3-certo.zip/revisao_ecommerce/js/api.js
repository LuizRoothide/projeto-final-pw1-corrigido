const API_BASE_URL = "https://ppw-1-tads.vercel.app";

async function apiRequest(caminho, opcoes) {
    opcoes = opcoes || {};
    const configuracao = {
        method: opcoes.method || "GET",
        headers: Object.assign({ "Content-Type": "application/json" }, opcoes.headers || {})
    };

    if (opcoes.body !== undefined) {
        configuracao.body = JSON.stringify(opcoes.body);
    }

    let resposta;
    try {
        resposta = await fetch(API_BASE_URL + caminho, configuracao);
    } catch (erro) {
        return { status: 0, ok: false, data: null, erroRede: true };
    }

    let dados = null;
    try {
        dados = await resposta.json();
    } catch (erro) {
        dados = null;
    }

    return { status: resposta.status, ok: resposta.ok, data: dados, erroRede: false };
}

function montarQueryString(parametros) {
    const partes = [];
    for (const chave in parametros) {
        const valor = parametros[chave];
        if (valor !== undefined && valor !== null && valor !== "") {
            partes.push(encodeURIComponent(chave) + "=" + encodeURIComponent(valor));
        }
    }
    return partes.length > 0 ? "?" + partes.join("&") : "";
}

function extrairLista(dados, chaves) {
    if (Array.isArray(dados)) {
        return dados;
    }
    if (dados === null || typeof dados !== "object") {
        return [];
    }
    for (let i = 0; i < chaves.length; i++) {
        if (Array.isArray(dados[chaves[i]])) {
            return dados[chaves[i]];
        }
    }
    return [];
}

function extrairObjeto(dados, chaves) {
    if (dados === null || typeof dados !== "object") {
        return null;
    }
    for (let i = 0; i < chaves.length; i++) {
        if (dados[chaves[i]] && typeof dados[chaves[i]] === "object") {
            return dados[chaves[i]];
        }
    }
    const ignorar = ["sucesso", "mensagem", "message", "success", "token"];
    const sobrou = {};
    let encontrouAlgo = false;
    for (const chave in dados) {
        if (ignorar.indexOf(chave) === -1) {
            sobrou[chave] = dados[chave];
            encontrouAlgo = true;
        }
    }
    return encontrouAlgo ? sobrou : null;
}

function extrairMensagem(dados, padrao) {
    if (dados && typeof dados === "object") {
        if (typeof dados.mensagem === "string") {
            return dados.mensagem;
        }
        if (typeof dados.message === "string") {
            return dados.message;
        }
    }
    return padrao;
}

function buscarProdutos(filtros) {
    filtros = filtros || {};
    const query = montarQueryString({
        search: filtros.busca,
        category: filtros.categoria
    });
    return apiRequest("/api/products" + query, { method: "GET" });
}

function registrarUsuario(nome, email, senha, confirmacaoSenha) {
    return apiRequest("/api/register", {
        method: "POST",
        body: { nome: nome, email: email, senha: senha, confirmacaoSenha: confirmacaoSenha }
    });
}

function logarUsuario(email, senha) {
    return apiRequest("/api/login", {
        method: "POST",
        body: { email: email, senha: senha }
    });
}

function calcularFrete(cep) {
    return apiRequest("/api/frete", {
        method: "POST",
        body: { cep: cep }
    });
}

function aplicarCupom(codigo, subtotal) {
    return apiRequest("/api/cupom", {
        method: "POST",
        body: { codigo: codigo, subtotal: subtotal }
    });
}

function finalizarCompra(itens, cep, metodoPagamento, numeroCartao) {
    const corpo = { itens: itens, cep: cep, metodoPagamento: metodoPagamento };
    if (numeroCartao) {
        corpo.numeroCartao = numeroCartao;
    }
    return apiRequest("/api/checkout", { method: "POST", body: corpo });
}

function cancelarPedidoApi(protocolo) {
    return apiRequest("/api/pedido" + montarQueryString({ protocolo: protocolo }), { method: "DELETE" });
}

function atualizarDadosUsuario(nome, email) {
    return apiRequest("/api/user", { method: "PUT", body: { nome: nome, email: email } });
}
