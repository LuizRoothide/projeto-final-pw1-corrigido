const usuarioAtual = exigirLogin();

if (usuarioAtual !== null) {
    const campoNome = document.getElementById("nome");
    const campoEmail = document.getElementById("email");
    const formulario = document.getElementById("form-dados");
    const areaMensagem = document.getElementById("area-mensagem");
    const botaoAlterar = formulario.querySelector("button[type='submit']");

    campoNome.value = usuarioAtual.nome || "";
    campoEmail.value = usuarioAtual.email || "";

    const mensagensPorStatus = {
        400: (dados) => extrairMensagem(dados, "Informe nome e e-mail válidos."),
        409: (dados) => extrairMensagem(dados, "Este e-mail já está em uso."),
    };

    formulario.addEventListener("submit", async (evento) => {
        evento.preventDefault();
        areaMensagem.innerHTML = "";

        const nome = campoNome.value.trim();
        const email = campoEmail.value.trim();

        if (nome === "" || email === "") {
            exibirAlerta(areaMensagem, "warning", "Preencha nome e e-mail.");
            return;
        }

        botaoAlterar.disabled = true;
        const resposta = await atualizarDadosUsuario(nome, email);
        botaoAlterar.disabled = false;

        if (resposta.erroRede) {
            exibirAlerta(areaMensagem, "danger", "Não foi possível conectar à loja agora. Tente novamente em instantes.");
            return;
        }

        if (resposta.status === 200 && resposta.ok) {
            const usuarioAtualizado = Object.assign({}, usuarioAtual, { nome: nome, email: email });
            localStorage.setItem("usuarioLogado", JSON.stringify(usuarioAtualizado));
            exibirAlerta(areaMensagem, "success", extrairMensagem(resposta.data, "Dados atualizados com sucesso!"));
            montarMenuUsuario();
            return;
        }

        const gerarMensagem = mensagensPorStatus[resposta.status];
        const tipoAlerta = resposta.status === 409 ? "warning" : "danger";
        exibirAlerta(areaMensagem, tipoAlerta, gerarMensagem ? gerarMensagem(resposta.data) : extrairMensagem(resposta.data, "Não foi possível atualizar os dados."));
    });
}
