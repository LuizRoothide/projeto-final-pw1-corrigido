const formulario = document.getElementById("form-cadastro");
const areaMensagem = document.getElementById("area-mensagem");
const botaoCadastrar = formulario.querySelector("button[type='submit']");

formulario.addEventListener("submit", async function (evento) {
    evento.preventDefault();
    areaMensagem.innerHTML = "";

    const nome = document.getElementById("nome").value.trim();
    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value;
    const confirmacao = document.getElementById("confirmacao").value;

    if (nome === "" || email === "" || senha === "" || confirmacao === "") {
        exibirAlerta(areaMensagem, "warning", "Preencha todos os campos.");
        return;
    }

    botaoCadastrar.disabled = true;
    const resposta = await registrarUsuario(nome, email, senha, confirmacao);
    botaoCadastrar.disabled = false;

    if (resposta.erroRede) {
        exibirAlerta(areaMensagem, "danger", "Não foi possível conectar à loja agora. Tente novamente em instantes.");
        return;
    }

    if (resposta.status === 201 && resposta.ok) {
        exibirAlerta(areaMensagem, "success", extrairMensagem(resposta.data, "Cadastro realizado com sucesso!"));
        setTimeout(function () {
            window.location.href = "login.html";
        }, 1200);
        return;
    }

    if (resposta.status === 400) {
        exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "Verifique os campos: algum está faltando, o e-mail é inválido ou as senhas não coincidem."));
        return;
    }

    if (resposta.status === 409) {
        exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "Este e-mail já está cadastrado."));
        return;
    }

    if (resposta.status === 422) {
        exibirAlerta(areaMensagem, "warning", extrairMensagem(resposta.data, "A senha precisa ter pelo menos 6 caracteres."));
        return;
    }

    exibirAlerta(areaMensagem, "danger", extrairMensagem(resposta.data, "Não foi possível concluir o cadastro."));
});
